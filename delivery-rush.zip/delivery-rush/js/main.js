import { buildShift, newRun, quote, commit, SHIFTS, W, H, RIVER, BRIDGES, REST, HOMES } from './engine/sim.js';
import { runAlgo } from './engine/algo.js';
import { average, verdict, lateCount, losses, LATE } from './engine/score.js';

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
const beat = Number(params.get('beat')) / 10 || null;
let shift, run, i, mine, history, hint = false;

function start(key) {
  shift = buildShift(key); run = newRun(); i = 0; mine = []; history = [];
  render();
}
function pick(ri) {
  history.push(JSON.parse(JSON.stringify(run.riders)));
  mine.push(commit(shift, run, ri, shift.orders[i])); i++; render();
}
function undo() { if (i) { i--; mine.pop(); run.riders = history.pop(); render(); } }

function drawCity() {
  const S = 36, o = shift.orders[i];
  let s = `<svg viewBox="0 0 ${W * S} ${H * S}" role="img" aria-label="City grid">`;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const k = x + ',' + y, px = x * S, py = y * S;
    let fill = 'var(--cell)';
    if (x === RIVER) fill = shift.open.includes(y) ? 'var(--bridge)' : 'var(--river)';
    else if (shift.blocked.has(k)) fill = 'var(--block)';
    s += `<rect x="${px}" y="${py}" width="${S}" height="${S}" fill="${fill}" stroke="var(--line)"/>`;
    if (x === RIVER && BRIDGES.includes(y) && !shift.open.includes(y))
      s += `<text x="${px + 18}" y="${py + 24}" text-anchor="middle" fill="var(--bad)" font-size="20">✕</text>`;
  }
  const tag = (p, label, cls, hot) =>
    `<g class="${cls}${hot ? ' hot' : ''}"><rect x="${p[0] * S + 4}" y="${p[1] * S + 4}" width="${S - 8}" height="${S - 8}" rx="${cls === 'h' ? 14 : 4}"/>` +
    `<text x="${p[0] * S + 18}" y="${p[1] * S + 23}" text-anchor="middle">${label}</text></g>`;
  REST.forEach((p, n) => (s += tag(p, 'R' + (n + 1), 'r', o && o.rest === p)));
  HOMES.forEach((p, n) => (s += tag(p, 'H' + (n + 1), 'h', o && o.home === p)));
  run.riders.forEach((r) => (s += `<g class="rider"><circle cx="${r.pos[0] * S + 18}" cy="${r.pos[1] * S + 18}" r="11"/><text x="${r.pos[0] * S + 18}" y="${r.pos[1] * S + 23}" text-anchor="middle">${r.id}</text></g>`));
  return s + '</svg>';
}
const name = (list, p) => list.findIndex((q) => q === p) + 1;

function panel() {
  if (i < shift.orders.length) {
    const o = shift.orders[i];
    const btns = run.riders.map((r, n) => {
      const q = quote(shift, r, o);
      return `<button class="rb" data-r="${n}">Rider ${r.id}<small>${hint ? q.time + ' min' : 'free at ' + r.free}</small></button>`;
    }).join('');
    return `<p class="meta">Order ${i + 1} of ${shift.orders.length} · clock ${o.t}</p>
      <h2>R${name(REST, o.rest)} → H${name(HOMES, o.home)}</h2>
      <p>Pick the rider who will deliver this earliest. Keys 1–4 also work.</p>
      <div class="riders">${btns}</div>
      <label><input type="checkbox" id="hint" ${hint ? 'checked' : ''}/> Show delivery time per rider</label>
      <div class="row"><button id="undo" ${i ? '' : 'disabled'}>Undo</button><button id="restart">Restart</button></div>`;
  }
  const { times: algo } = runAlgo(shift);
  const you = average(mine), al = average(algo), v = verdict(you, al);
  const words = { win: 'You win. Your average is lower.', close: 'Close. Within 10% of the algorithm.', behind: 'Behind. The algorithm is more than 10% faster.' };
  const ls = losses(mine, algo).map((l) => `<li>Order ${l.id + 1}: +${l.diff} min slower</li>`).join('') || '<li>None. You matched or beat it on every order.</li>';
  const link = `${location.origin}${location.pathname}?shift=${shift.key}&beat=${Math.round(you * 10)}`;
  const chal = beat ? `<p>${you < beat ? 'You beat' : 'You missed'} the challenge of ${beat.toFixed(1)} min.</p>` : '';
  return `<h2>Shift complete</h2><p>You: ${you.toFixed(1)} min · Algorithm: ${al.toFixed(1)} min</p>
    <p class="verdict ${v}">${words[v]}</p>${chal}
    <p>Late (over ${LATE} min): you ${lateCount(mine)}, algorithm ${lateCount(algo)}</p>
    <h3>Your three biggest losses</h3><ul>${ls}</ul>
    <p class="meta">Challenge link</p><input class="link" readonly value="${link}"/>
    <div class="row"><button id="undo">Undo</button><button id="restart">Play again</button></div>`;
}

function render() {
  $('city').innerHTML = drawCity();
  $('panel').innerHTML = panel();
  document.querySelectorAll('[data-shift]').forEach((b) => b.classList.toggle('on', b.dataset.shift === shift.key));
  document.querySelectorAll('.rb').forEach((b) => (b.onclick = () => pick(+b.dataset.r)));
  $('undo') && ($('undo').onclick = undo);
  $('restart') && ($('restart').onclick = () => start(shift.key));
  $('hint') && ($('hint').onchange = (e) => { hint = e.target.checked; render(); });
}
document.addEventListener('keydown', (e) => {
  if (i < shift.orders.length && '1234'.includes(e.key)) pick(+e.key - 1);
});
$('shifts').innerHTML = Object.entries(SHIFTS).map(([k, s]) => `<button data-shift="${k}">${s.name}</button>`).join('');
document.querySelectorAll('[data-shift]').forEach((b) => (b.onclick = () => start(b.dataset.shift)));
$('themeBtn').onclick = () => {
  const n = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
  document.documentElement.dataset.theme = n;
  try { localStorage.setItem('theme', n); } catch {}
};
if (beat) $('challenge').textContent = `Challenge: beat an average of ${beat.toFixed(1)} min`;
start(SHIFTS[params.get('shift')] ? params.get('shift') : 'lunch');
