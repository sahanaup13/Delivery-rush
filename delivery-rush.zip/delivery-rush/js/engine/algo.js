import { MinHeap } from './heap.js';
import { newRun, quote, commit } from './sim.js';
// Dispatcher: min-heap of waiting orders (by arrival), greedy rider = earliest finish.
export function runAlgo(shift) {
  const heap = new MinHeap((o) => o.t), run = newRun(), times = [], picks = [];
  shift.orders.forEach((o) => heap.push(o));
  while (heap.size) {
    const o = heap.pop();
    let best = 0;
    run.riders.forEach((r, i) => {
      if (quote(shift, r, o).finish < quote(shift, run.riders[best], o).finish) best = i;
    });
    times[o.id] = commit(shift, run, best, o); picks[o.id] = best;
  }
  return { times, picks };
}
