import { bfs } from './bfs.js';
export const W = 13, H = 13, RIVER = 6;
export const BRIDGES = [2, 6, 10];
export const REST = [[1,1],[3,5],[2,10],[9,1],[10,6],[8,11]];
export const HOMES = [[0,4],[4,0],[5,3],[2,7],[5,8],[4,12],[1,12],[8,4],[11,2],[12,8],[7,9],[11,11]];
const RIDER_START = { A: [2,2], B: [4,6], C: [8,5], D: [10,10] };
const BUILDINGS = [[3,2],[4,2],[8,3],[9,3],[9,9],[10,9],[3,9],[4,9]];
// 12 + 14 + 16 = 42 orders in total
export const SHIFTS = {
  lunch: { name: 'Lunch Rush', open: [2, 6, 10], count: 12, seed: 7 },
  rain:  { name: 'Rain Shift', open: [6, 10],    count: 14, seed: 21 },
  night: { name: 'Night Shift', open: [6],       count: 16, seed: 42 },
};
function rng(seed) { let s = seed; return () => (s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296; }

export function buildShift(key) {
  const def = SHIFTS[key], blocked = new Set(BUILDINGS.map((b) => b.join(',')));
  for (let y = 0; y < H; y++) if (!def.open.includes(y)) blocked.add(RIVER + ',' + y);
  const r = rng(def.seed); let t = 0;
  const orders = Array.from({ length: def.count }, (_, id) => {
    t += 1 + Math.floor(r() * 3);
    return { id, t, rest: REST[Math.floor(r() * 6)], home: HOMES[Math.floor(r() * 12)] };
  });
  const cache = new Map();
  const dist = (a, b) => {
    const k = a.join(',');
    if (!cache.has(k)) cache.set(k, bfs(blocked, W, H, a[0], a[1]));
    return cache.get(k)[b[1] * W + b[0]];
  };
  return { key, ...def, blocked, orders, dist };
}
export const newRun = () => ({
  riders: Object.entries(RIDER_START).map(([id, pos]) => ({ id, pos, free: 0 })),
});
// What would happen if this rider took this order? (1 grid step = 1 minute)
export function quote(shift, rider, o) {
  const start = Math.max(rider.free, o.t);
  const finish = start + shift.dist(rider.pos, o.rest) + shift.dist(o.rest, o.home);
  return { finish, time: finish - o.t };
}
export function commit(shift, run, ri, o) {
  const q = quote(shift, run.riders[ri], o);
  run.riders[ri].free = q.finish; run.riders[ri].pos = o.home;
  return q.time;
}
