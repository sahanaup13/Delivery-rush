import { Queue } from './queue.js';
// Shortest step count from (sx,sy) to every cell; -1 = unreachable.
export function bfs(blocked, W, H, sx, sy) {
  const d = new Array(W * H).fill(-1), q = new Queue();
  d[sy * W + sx] = 0; q.push([sx, sy]);
  let c;
  while ((c = q.shift())) {
    const [x, y] = c;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const i = ny * W + nx;
      if (d[i] >= 0 || blocked.has(nx + ',' + ny)) continue;
      d[i] = d[y * W + x] + 1; q.push([nx, ny]);
    }
  }
  return d;
}
