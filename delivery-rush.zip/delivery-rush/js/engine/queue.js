// FIFO queue (head pointer, so shift() is O(1))
export class Queue {
  constructor() { this.a = []; this.h = 0; }
  push(v) { this.a.push(v); }
  shift() { return this.h < this.a.length ? this.a[this.h++] : undefined; }
  get size() { return this.a.length - this.h; }
}
