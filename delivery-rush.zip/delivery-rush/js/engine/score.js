export const LATE = 20;
export const average = (a) => a.reduce((s, x) => s + x, 0) / (a.length || 1);
export function verdict(you, algo) {
  if (you < algo) return 'win';
  return you <= algo * 1.1 ? 'close' : 'behind';
}
export const lateCount = (a) => a.filter((x) => x > LATE).length;
export function losses(you, algo) {
  return you.map((t, i) => ({ id: i, diff: t - algo[i] }))
    .filter((x) => x.diff > 0).sort((a, b) => b.diff - a.diff).slice(0, 3);
}
